/**
 * Database Module - SQLite via better-sqlite3
 * UniqueKingAI - uniquekingai.com
 */

const Database = require('better-sqlite3');
const path = require('path');

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '../data/vpnshop.db');

// Ensure data directory exists
const fs = require('fs');
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

const db = new Database(DB_PATH);

// Enable WAL for better performance
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// ─── Migrations ──────────────────────────────────────────────────────────────

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    balance INTEGER DEFAULT 0,
    joined_at TEXT,
    state TEXT DEFAULT NULL
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    slug TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    name_fa TEXT NOT NULL,
    description TEXT,
    description_fa TEXT,
    icon TEXT,
    type TEXT NOT NULL,
    variants TEXT NOT NULL,
    is_active INTEGER DEFAULT 1,
    sort_order INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    variant TEXT,
    quantity INTEGER DEFAULT 1,
    total_price INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    config_data TEXT,
    created_at TEXT,
    updated_at TEXT,
    FOREIGN KEY (telegram_id) REFERENCES users(telegram_id),
    FOREIGN KEY (product_id) REFERENCES products(id)
  );

  CREATE TABLE IF NOT EXISTS charge_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    amount INTEGER NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    processed_at TEXT,
    FOREIGN KEY (telegram_id) REFERENCES users(telegram_id)
  );

  CREATE TABLE IF NOT EXISTS admin_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    admin_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    target_id INTEGER,
    amount INTEGER,
    note TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

// ─── Seed Default Products ────────────────────────────────────────────────────

const seedProducts = () => {
  const count = db.prepare('SELECT COUNT(*) as c FROM products').get();
  if (count.c > 0) return;

  const insert = db.prepare(`
    INSERT INTO products (slug, name, name_fa, description, description_fa, icon, type, variants, sort_order)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const products = [
    {
      slug: 'multi-config',
      name: 'Multi Config',
      name_fa: 'کانفیگ مولتی',
      description: 'High-speed V2Ray multi-protocol config with multiple IPs',
      description_fa: 'کانفیگ چندپروتکلی V2Ray با سرعت بالا و چندین IP',
      icon: '🌐',
      type: 'volume',
      variants: JSON.stringify([
        { id: 'v10', label: '10 گیگ', label_en: '10 GB', volume_gb: 10, price: 25000 },
        { id: 'v20', label: '20 گیگ', label_en: '20 GB', volume_gb: 20, price: 45000 },
        { id: 'v50', label: '50 گیگ', label_en: '50 GB', volume_gb: 50, price: 90000 },
        { id: 'v100', label: '100 گیگ', label_en: '100 GB', volume_gb: 100, price: 160000 },
        { id: 'v200', label: '200 گیگ', label_en: '200 GB', volume_gb: 200, price: 280000 }
      ]),
      sort_order: 1
    },
    {
      slug: 'static-ip',
      name: 'Static IP Config',
      name_fa: 'کانفیگ آی‌پی استاتیک',
      description: 'V2Ray config with dedicated static IP address',
      description_fa: 'کانفیگ V2Ray با آدرس IP اختصاصی و ثابت',
      icon: '🔒',
      type: 'volume',
      variants: JSON.stringify([
        { id: 'v10', label: '10 گیگ', label_en: '10 GB', volume_gb: 10, price: 35000 },
        { id: 'v20', label: '20 گیگ', label_en: '20 GB', volume_gb: 20, price: 60000 },
        { id: 'v50', label: '50 گیگ', label_en: '50 GB', volume_gb: 50, price: 120000 },
        { id: 'v100', label: '100 گیگ', label_en: '100 GB', volume_gb: 100, price: 210000 },
        { id: 'v200', label: '200 گیگ', label_en: '200 GB', volume_gb: 200, price: 380000 }
      ]),
      sort_order: 2
    },
    {
      slug: 'starlink',
      name: 'Starlink Config',
      name_fa: 'کانفیگ استارلینک',
      description: 'Ultra-fast V2Ray config routed through Starlink network',
      description_fa: 'کانفیگ V2Ray فوق سریع از طریق شبکه استارلینک',
      icon: '🛸',
      type: 'volume',
      variants: JSON.stringify([
        { id: 'v10', label: '10 گیگ', label_en: '10 GB', volume_gb: 10, price: 55000 },
        { id: 'v20', label: '20 گیگ', label_en: '20 GB', volume_gb: 20, price: 95000 },
        { id: 'v50', label: '50 گیگ', label_en: '50 GB', volume_gb: 50, price: 200000 },
        { id: 'v100', label: '100 گیگ', label_en: '100 GB', volume_gb: 100, price: 360000 },
        { id: 'v200', label: '200 گیگ', label_en: '200 GB', volume_gb: 200, price: 650000 }
      ]),
      sort_order: 3
    },
    {
      slug: 'express-vpn',
      name: 'ExpressVPN Account',
      name_fa: 'اکانت اکسپرس VPN',
      description: 'Premium ExpressVPN account with subscription plans',
      description_fa: 'اکانت پریمیوم اکسپرس VPN با پلن‌های اشتراکی',
      icon: '⚡',
      type: 'subscription',
      variants: JSON.stringify([
        { id: 'm1', label: '۱ ماهه', label_en: '1 Month', months: 1, price: 120000 },
        { id: 'm3', label: '۳ ماهه', label_en: '3 Months', months: 3, price: 320000 },
        { id: 'm6', label: '۶ ماهه', label_en: '6 Months', months: 6, price: 580000 },
        { id: 'm12', label: '۱۲ ماهه', label_en: '12 Months', months: 12, price: 990000 }
      ]),
      sort_order: 4
    }
  ];

  const insertMany = db.transaction((items) => {
    for (const item of items) {
      insert.run(
        item.slug, item.name, item.name_fa,
        item.description, item.description_fa,
        item.icon, item.type, item.variants, item.sort_order
      );
    }
  });

  insertMany(products);
  console.log('✅ Default products seeded');
};

seedProducts();

// ─── User Functions ───────────────────────────────────────────────────────────

const upsertUser = (user) => {
  const stmt = db.prepare(`
    INSERT INTO users (telegram_id, username, first_name, last_name, joined_at)
    VALUES (@telegram_id, @username, @first_name, @last_name, @joined_at)
    ON CONFLICT(telegram_id) DO UPDATE SET
      username = excluded.username,
      first_name = excluded.first_name,
      last_name = excluded.last_name
  `);
  return stmt.run(user);
};

const getUser = (telegram_id) => {
  return db.prepare('SELECT * FROM users WHERE telegram_id = ?').get(telegram_id);
};

const getAllUsers = () => {
  return db.prepare(`
    SELECT u.*, 
      (SELECT COUNT(*) FROM orders WHERE telegram_id = u.telegram_id) as order_count
    FROM users u
    ORDER BY u.joined_at DESC
  `).all();
};

const addBalance = (telegram_id, amount) => {
  return db.prepare('UPDATE users SET balance = balance + ? WHERE telegram_id = ?').run(amount, telegram_id);
};

const deductBalance = (telegram_id, amount) => {
  return db.prepare('UPDATE users SET balance = balance - ? WHERE telegram_id = ?').run(amount, telegram_id);
};

const setUserState = (telegram_id, state) => {
  return db.prepare('UPDATE users SET state = ? WHERE telegram_id = ?').run(state, telegram_id);
};

const getUserState = (telegram_id) => {
  const row = db.prepare('SELECT state FROM users WHERE telegram_id = ?').get(telegram_id);
  return row?.state || null;
};

const clearUserState = (telegram_id) => {
  return db.prepare('UPDATE users SET state = NULL WHERE telegram_id = ?').run(telegram_id);
};

// ─── Product Functions ────────────────────────────────────────────────────────

const getProducts = () => {
  const products = db.prepare('SELECT * FROM products WHERE is_active = 1 ORDER BY sort_order').all();
  return products.map(p => ({ ...p, variants: JSON.parse(p.variants) }));
};

const getProductById = (id) => {
  const p = db.prepare('SELECT * FROM products WHERE id = ?').get(id);
  if (!p) return null;
  return { ...p, variants: JSON.parse(p.variants) };
};

const updateProduct = (id, data) => {
  if (data.variants && typeof data.variants === 'object') {
    data.variants = JSON.stringify(data.variants);
  }
  const fields = Object.keys(data).map(k => `${k} = @${k}`).join(', ');
  return db.prepare(`UPDATE products SET ${fields} WHERE id = @id`).run({ ...data, id });
};

// ─── Order Functions ──────────────────────────────────────────────────────────

const createOrder = (order) => {
  const stmt = db.prepare(`
    INSERT INTO orders (telegram_id, product_id, variant, quantity, total_price, status, created_at)
    VALUES (@telegram_id, @product_id, @variant, @quantity, @total_price, @status, @created_at)
  `);
  const result = stmt.run(order);
  return result.lastInsertRowid;
};

const getUserOrders = (telegram_id) => {
  return db.prepare(`
    SELECT o.*, p.name_fa as product_name
    FROM orders o
    LEFT JOIN products p ON o.product_id = p.id
    WHERE o.telegram_id = ?
    ORDER BY o.created_at DESC
  `).all(telegram_id);
};

const getAllOrders = () => {
  return db.prepare(`
    SELECT o.*, p.name_fa as product_name, u.first_name, u.username
    FROM orders o
    LEFT JOIN products p ON o.product_id = p.id
    LEFT JOIN users u ON o.telegram_id = u.telegram_id
    ORDER BY o.created_at DESC
  `).all();
};

const getOrderById = (id) => {
  return db.prepare('SELECT * FROM orders WHERE id = ?').get(id);
};

const updateOrder = (id, data) => {
  data.updated_at = new Date().toISOString();
  const fields = Object.keys(data).map(k => `${k} = @${k}`).join(', ');
  return db.prepare(`UPDATE orders SET ${fields} WHERE id = @id`).run({ ...data, id });
};

// ─── Charge Request Functions ────────────────────────────────────────────────

const createChargeRequest = (req) => {
  const stmt = db.prepare(`
    INSERT INTO charge_requests (telegram_id, amount, status, created_at)
    VALUES (@telegram_id, @amount, @status, @created_at)
  `);
  return stmt.run(req).lastInsertRowid;
};

const getAllChargeRequests = () => {
  return db.prepare(`
    SELECT cr.*, u.first_name, u.username
    FROM charge_requests cr
    LEFT JOIN users u ON cr.telegram_id = u.telegram_id
    ORDER BY cr.created_at DESC
  `).all();
};

const approveChargeRequest = (id) => {
  return db.prepare(`
    UPDATE charge_requests SET status = 'approved', processed_at = datetime('now') WHERE id = ?
  `).run(id);
};

const rejectChargeRequest = (id) => {
  return db.prepare(`
    UPDATE charge_requests SET status = 'rejected', processed_at = datetime('now') WHERE id = ?
  `).run(id);
};

// ─── Admin Log ────────────────────────────────────────────────────────────────

const logAdminAction = (data) => {
  return db.prepare(`
    INSERT INTO admin_logs (admin_id, action, target_id, amount, note)
    VALUES (@admin_id, @action, @target_id, @amount, @note)
  `).run(data);
};

module.exports = {
  upsertUser, getUser, getAllUsers, addBalance, deductBalance,
  setUserState, getUserState, clearUserState,
  getProducts, getProductById, updateProduct,
  createOrder, getUserOrders, getAllOrders, getOrderById, updateOrder,
  createChargeRequest, getAllChargeRequests, approveChargeRequest, rejectChargeRequest,
  logAdminAction
};
