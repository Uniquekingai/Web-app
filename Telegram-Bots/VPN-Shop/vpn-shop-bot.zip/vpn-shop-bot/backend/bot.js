/**
 * VPN Shop Telegram Bot
 * UniqueKingAI - uniquekingai.com
 * Telegram Web App Bot for V2Ray Config Sales
 */

require('dotenv').config();
const { Telegraf } = require('telegraf');
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');

const bot = new Telegraf(process.env.BOT_TOKEN);
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/dist')));

const WEB_APP_URL = process.env.WEB_APP_URL || 'https://your-domain.com';
const ADMIN_IDS = (process.env.ADMIN_IDS || '').split(',').map(id => parseInt(id.trim())).filter(Boolean);

// ─── Bot Commands ────────────────────────────────────────────────────────────

bot.start(async (ctx) => {
  const user = ctx.from;
  
  // Register or update user
  await db.upsertUser({
    telegram_id: user.id,
    username: user.username || null,
    first_name: user.first_name || '',
    last_name: user.last_name || '',
    joined_at: new Date().toISOString()
  });

  const isAdmin = ADMIN_IDS.includes(user.id);

  const keyboard = {
    inline_keyboard: [
      [
        {
          text: '🛒 فروشگاه VPN',
          web_app: { url: `${WEB_APP_URL}/?user_id=${user.id}` }
        }
      ],
      [
        {
          text: '💰 کیف پول من',
          callback_data: 'wallet'
        },
        {
          text: '📋 سفارشات من',
          callback_data: 'my_orders'
        }
      ],
      [
        {
          text: '💳 درخواست شارژ کیف پول',
          callback_data: 'charge_request'
        }
      ]
    ]
  };

  if (isAdmin) {
    keyboard.inline_keyboard.push([
      {
        text: '⚙️ پنل مدیریت',
        web_app: { url: `${WEB_APP_URL}/admin?admin_id=${user.id}` }
      }
    ]);
  }

  await ctx.reply(
    `👋 سلام *${user.first_name}* عزیز!\n\n` +
    `🔐 به فروشگاه VPN خوش آمدید\n` +
    `💎 بهترین کانفیگ‌های V2Ray را از ما بخرید\n\n` +
    `برای مشاهده محصولات دکمه *فروشگاه VPN* را بزنید 👇`,
    {
      parse_mode: 'Markdown',
      reply_markup: keyboard
    }
  );
});

// Wallet balance
bot.action('wallet', async (ctx) => {
  await ctx.answerCbQuery();
  const user = await db.getUser(ctx.from.id);
  if (!user) return ctx.reply('❌ لطفاً ابتدا /start بزنید');
  
  await ctx.reply(
    `💰 *کیف پول شما*\n\n` +
    `موجودی: *${(user.balance || 0).toLocaleString('fa')} تومان*\n\n` +
    `برای شارژ کیف پول از دکمه «درخواست شارژ» استفاده کنید.`,
    { parse_mode: 'Markdown' }
  );
});

// Charge request
bot.action('charge_request', async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(
    `💳 *درخواست شارژ کیف پول*\n\n` +
    `مبلغ مورد نظر را به صورت عدد وارد کنید (تومان):\n` +
    `مثال: 100000`,
    { parse_mode: 'Markdown' }
  );
  
  // Set state for waiting amount
  await db.setUserState(ctx.from.id, 'waiting_charge_amount');
});

// My orders
bot.action('my_orders', async (ctx) => {
  await ctx.answerCbQuery();
  const orders = await db.getUserOrders(ctx.from.id);
  
  if (!orders || orders.length === 0) {
    return ctx.reply('📭 شما هنوز سفارشی ثبت نکرده‌اید.');
  }

  const orderList = orders.slice(0, 5).map((o, i) => 
    `${i + 1}. ${o.product_name} - ${o.amount.toLocaleString('fa')} تومان - ${o.status === 'completed' ? '✅' : '⏳'}`
  ).join('\n');

  await ctx.reply(
    `📋 *آخرین سفارشات شما:*\n\n${orderList}`,
    { parse_mode: 'Markdown' }
  );
});

// Handle text messages (for charge amount input)
bot.on('text', async (ctx) => {
  if (ctx.message.text.startsWith('/')) return;
  
  const state = await db.getUserState(ctx.from.id);
  
  if (state === 'waiting_charge_amount') {
    const amount = parseInt(ctx.message.text.replace(/[^0-9]/g, ''));
    
    if (isNaN(amount) || amount < 10000) {
      return ctx.reply('❌ مبلغ وارد شده معتبر نیست. حداقل مبلغ 10,000 تومان است.');
    }

    await db.clearUserState(ctx.from.id);
    
    // Create charge request
    const requestId = await db.createChargeRequest({
      telegram_id: ctx.from.id,
      amount: amount,
      status: 'pending',
      created_at: new Date().toISOString()
    });

    // Notify admins
    for (const adminId of ADMIN_IDS) {
      try {
        const user = ctx.from;
        await bot.telegram.sendMessage(
          adminId,
          `💳 *درخواست شارژ جدید*\n\n` +
          `👤 کاربر: ${user.first_name} ${user.last_name || ''}\n` +
          `🆔 آیدی: @${user.username || user.id}\n` +
          `💰 مبلغ: *${amount.toLocaleString('fa')} تومان*\n` +
          `🔢 شماره درخواست: #${requestId}`,
          {
            parse_mode: 'Markdown',
            reply_markup: {
              inline_keyboard: [[
                { text: '✅ تأیید و شارژ', callback_data: `approve_charge_${requestId}_${ctx.from.id}_${amount}` },
                { text: '❌ رد کردن', callback_data: `reject_charge_${requestId}_${ctx.from.id}` }
              ]]
            }
          }
        );
      } catch (e) {
        console.error(`Failed to notify admin ${adminId}:`, e.message);
      }
    }

    await ctx.reply(
      `✅ *درخواست شارژ ثبت شد*\n\n` +
      `مبلغ: *${amount.toLocaleString('fa')} تومان*\n` +
      `شماره درخواست: *#${requestId}*\n\n` +
      `پس از تأیید توسط ادمین، موجودی شما شارژ خواهد شد.`,
      { parse_mode: 'Markdown' }
    );
  }
});

// Admin: approve charge
bot.action(/approve_charge_(\d+)_(\d+)_(\d+)/, async (ctx) => {
  if (!ADMIN_IDS.includes(ctx.from.id)) return ctx.answerCbQuery('❌ دسترسی ندارید');
  
  const [, requestId, userId, amount] = ctx.match;
  
  await db.approveChargeRequest(parseInt(requestId));
  await db.addBalance(parseInt(userId), parseInt(amount));
  
  // Notify user
  try {
    await bot.telegram.sendMessage(
      parseInt(userId),
      `✅ *کیف پول شما شارژ شد!*\n\n` +
      `مبلغ *${parseInt(amount).toLocaleString('fa')} تومان* به موجودی شما اضافه شد.`,
      { parse_mode: 'Markdown' }
    );
  } catch (e) {}

  await ctx.editMessageText(
    ctx.callbackQuery.message.text + '\n\n✅ *تأیید شد*',
    { parse_mode: 'Markdown' }
  );
  await ctx.answerCbQuery('✅ موجودی کاربر شارژ شد');
});

// Admin: reject charge
bot.action(/reject_charge_(\d+)_(\d+)/, async (ctx) => {
  if (!ADMIN_IDS.includes(ctx.from.id)) return ctx.answerCbQuery('❌ دسترسی ندارید');
  
  const [, requestId, userId] = ctx.match;
  
  await db.rejectChargeRequest(parseInt(requestId));
  
  try {
    await bot.telegram.sendMessage(
      parseInt(userId),
      `❌ *درخواست شارژ رد شد*\n\nدرخواست شارژ شما توسط ادمین رد شد. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.`,
      { parse_mode: 'Markdown' }
    );
  } catch (e) {}

  await ctx.editMessageText(
    ctx.callbackQuery.message.text + '\n\n❌ *رد شد*',
    { parse_mode: 'Markdown' }
  );
  await ctx.answerCbQuery('❌ درخواست رد شد');
});

// ─── REST API ────────────────────────────────────────────────────────────────

// Get products & prices
app.get('/api/products', async (req, res) => {
  const products = await db.getProducts();
  res.json(products);
});

// Get user info
app.get('/api/user/:telegram_id', async (req, res) => {
  const user = await db.getUser(parseInt(req.params.telegram_id));
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(user);
});

// Place order
app.post('/api/order', async (req, res) => {
  const { telegram_id, product_id, variant, quantity, total_price } = req.body;
  
  if (!telegram_id || !product_id || !total_price) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const user = await db.getUser(telegram_id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  
  if ((user.balance || 0) < total_price) {
    return res.status(400).json({ error: 'insufficient_balance', balance: user.balance });
  }

  const orderId = await db.createOrder({
    telegram_id,
    product_id,
    variant,
    quantity,
    total_price,
    status: 'pending',
    created_at: new Date().toISOString()
  });

  await db.deductBalance(telegram_id, total_price);

  // Notify admins
  const product = await db.getProductById(product_id);
  const userInfo = ctx => ctx;
  for (const adminId of ADMIN_IDS) {
    try {
      await bot.telegram.sendMessage(
        adminId,
        `🛒 *سفارش جدید #${orderId}*\n\n` +
        `👤 کاربر: ${user.first_name} (${user.telegram_id})\n` +
        `📦 محصول: ${product?.name || product_id}\n` +
        `🔧 نوع: ${variant || '-'}\n` +
        `💰 مبلغ: *${total_price.toLocaleString('fa')} تومان*`,
        { parse_mode: 'Markdown' }
      );
    } catch (e) {}
  }

  res.json({ success: true, order_id: orderId });
});

// Admin: get all users
app.get('/api/admin/users', async (req, res) => {
  const adminId = parseInt(req.headers['x-admin-id']);
  if (!ADMIN_IDS.includes(adminId)) return res.status(403).json({ error: 'Forbidden' });
  
  const users = await db.getAllUsers();
  res.json(users);
});

// Admin: add balance
app.post('/api/admin/balance', async (req, res) => {
  const adminId = parseInt(req.headers['x-admin-id']);
  if (!ADMIN_IDS.includes(adminId)) return res.status(403).json({ error: 'Forbidden' });
  
  const { telegram_id, amount, note } = req.body;
  await db.addBalance(telegram_id, amount);
  await db.logAdminAction({ admin_id: adminId, action: 'add_balance', target_id: telegram_id, amount, note });
  
  try {
    await bot.telegram.sendMessage(
      telegram_id,
      `✅ *موجودی کیف پول شما شارژ شد*\n\nمبلغ *${amount.toLocaleString('fa')} تومان* اضافه شد.\n${note ? `📝 یادداشت: ${note}` : ''}`,
      { parse_mode: 'Markdown' }
    );
  } catch (e) {}

  res.json({ success: true });
});

// Admin: get all orders
app.get('/api/admin/orders', async (req, res) => {
  const adminId = parseInt(req.headers['x-admin-id']);
  if (!ADMIN_IDS.includes(adminId)) return res.status(403).json({ error: 'Forbidden' });
  
  const orders = await db.getAllOrders();
  res.json(orders);
});

// Admin: update order status
app.put('/api/admin/orders/:id', async (req, res) => {
  const adminId = parseInt(req.headers['x-admin-id']);
  if (!ADMIN_IDS.includes(adminId)) return res.status(403).json({ error: 'Forbidden' });
  
  const { status, config_data } = req.body;
  await db.updateOrder(parseInt(req.params.id), { status, config_data });
  
  if (status === 'completed' && config_data) {
    const order = await db.getOrderById(parseInt(req.params.id));
    if (order) {
      try {
        await bot.telegram.sendMessage(
          order.telegram_id,
          `✅ *سفارش شما آماده است!*\n\n` +
          `📦 سفارش #${order.id}\n\n` +
          `🔐 کانفیگ شما:\n\`\`\`\n${config_data}\n\`\`\``,
          { parse_mode: 'Markdown' }
        );
      } catch (e) {}
    }
  }
  
  res.json({ success: true });
});

// Admin: update product prices
app.put('/api/admin/products/:id', async (req, res) => {
  const adminId = parseInt(req.headers['x-admin-id']);
  if (!ADMIN_IDS.includes(adminId)) return res.status(403).json({ error: 'Forbidden' });
  
  await db.updateProduct(parseInt(req.params.id), req.body);
  res.json({ success: true });
});

// Admin: get charge requests
app.get('/api/admin/charge-requests', async (req, res) => {
  const adminId = parseInt(req.headers['x-admin-id']);
  if (!ADMIN_IDS.includes(adminId)) return res.status(403).json({ error: 'Forbidden' });
  
  const requests = await db.getAllChargeRequests();
  res.json(requests);
});

// Serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/dist/index.html'));
});

// ─── Start ───────────────────────────────────────────────────────────────────

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});

bot.launch().then(() => {
  console.log('🤖 Bot started successfully');
});

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));
